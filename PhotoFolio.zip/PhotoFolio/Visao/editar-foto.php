
<?php

session_start();
 ?>

<!doctype html>

<?php
// Verifica se os dados foram recebidos via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Obtém os dados enviados
  $usuario = $_POST['usuario'];
  $nomeusuario = $_POST['nomeusuario'];

  // Faz alguma coisa com os dados recebidos, se necessário
  // ...

  // Configura as variáveis de sessão, se necessário
  $_SESSION['usuario'] = $usuario;
  $_SESSION['nomeusuario'] = $nomeusuario;

} else {
  header("Location: login.php");
  exit;
}
include 'menu.php';
include '..\Controladora\conexao.php';
//include '..\Modelo\Foto.php';
include '..\Repositorio\ImagemRepositorio.php';

$imagensRepositorio = new ImagemRepositorio($conn);
$imagens = $imagensRepositorio->listarFotoPorId($_POST['id']);



?>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>PhotoFolio Bootstrap Template - Gallery</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Cardo:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/main.css" rel="stylesheet">
  <link href="../assets/css/admin.css" rel="stylesheet">
  <link href="../assets/css/menu.css" rel="stylesheet">
  <link href="../assets/css/reset.css" rel="stylesheet">


  <!-- =======================================================
  * Template Name: PhotoFolio
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/photofolio-bootstrap-photography-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center  me-auto me-lg-0">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <i class="bi bi-camera"></i>
        <h1>PhotoFolio</h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php" class="active">Home</a></li>
          <li class="dropdown"><a href="#"><span>Galeria</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
              <li><a href="natureza.php">Natureza</a></li>
              <li><a href="pessoas.php">Pessoas</a></li>
              <li><a href="arquitetura.php">Arquitetura</a></li>
              <li><a href="animais.php">Animais</a></li>
              <li><a href="viagem.php">Viagens</a></li>
            </ul>
          </li>
          <li class = "useraname dropdown">
            <a href="#">
            <?php
            if (isset($_SESSION["nomeusuario"])){
              echo "<li><a href='index.html' class='active'>".$_SESSION['nomeusuario']."</a></li>";
            }else{
              echo "<li><a href='login.php' class='active'>Entrar</a></li>";
            }
            ?>
            </a>
            
          </li>
        </ul>
      </nav><!-- .navbar -->

      <div class="header-social-links">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

    </div>
  </header><!-- End Header -->
  <div class "editar">
  <main>
    <section class="container-admin-banner">
      <!-- <img src="../img/logo-ifsp-removebg.png" class="logo-admin" alt="logo-serenatto"> -->
      <h1>Editar Foto</h1>
    </section>
    <section class="container-form">
      <form method="POST" action="../Controladora/processar-editar-foto.php" id="editarForm" enctype="multipart/form-data">

      <label for="nome">Nome</label>
        <input type="text" id="nome" name="nomeP" value="<?= $imagens->getNome(); ?>" required>
<br>
        <label for="descricao">Descrição</label>
        <input type="text" id="descricao" name="descricao" value="<?= $imagens->getDescricao(); ?>" required>
        <br>

        <label for="categoria">Categoria</label>
        <input type="text" id="categoria" name="categoria" value="<?= $imagens->getCategoria(); ?>" required>
        <br>

        <?php $imagemfake = $imagens->getImagem();


        // Remove a parte "C:\fakepath\" do valor (apenas no caso de navegadores baseados em Windows)
        $imagem = basename($imagemfake);

        // Agora, $imagem conterá apenas o nome do arquivo, sem a parte "C:\fakepath\"
        ?>
        <label for="imagem">Envie uma nova imagem do produto ou mantenha a imagem atual:
          <div class="container-foto">
          </div><?= $imagens->getImagem();//$imagem;
           ?>
        </label>
        
        <input type="file" name="imagem" accept="image/*" id="imagem" value="<?= $imagens->getImagem(); ?>">
        <input type='hidden' name='nomeusuario' value=<?= $_SESSION['nomeusuario'];?>>
        <input type='hidden' name='usuario' value=<?= $_SESSION['usuario'];?>>
        <input type="hidden" name="id" id="id" value="<?= $imagens->getId(); ?>">
        <input type="submit" name="editar" class="botao-cadastrar" value="Editar foto" />
      </form>

      </section>
    </main>
  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-maskmoney/3.0.2/jquery.maskMoney.min.js" integrity="sha512-Rdk63VC+1UYzGSgd3u2iadi0joUrcwX0IWp2rTh6KXFoAmgOjRS99Vynz1lJPT8dLjvo6JZOqpAHJyfCEZ5KoA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="js/index.js"></script>
  </div>
 
</body>

</html>