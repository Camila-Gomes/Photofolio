<!doctype html>
<?php
// Verifica se os dados foram recebidos via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 
  // Configura as variáveis de sessão, se necessário
  $_SESSION['usuario'] = $_POST['usuario'];
  $_SESSION['nomeusuario'] = $_POST['nomeusuario'];
} else {
  $usuario = $_POST['usuario'];
  header("Location: login.php?erro=$usuario");
  exit;
}
require_once 'menu.php';
require "..\Controladora\Autenticacao.php";


require_once('../Controladora/conexao.php');
//require_once('../Modelo/Foto.php');
require_once('../Repositorio/ImagemRepositorio.php');

$imagemRepositorio = new ImagemRepositorio($conn);
$imagens = $imagemRepositorio->listarFotos();


?>

<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>PhotoFolio Bootstrap Template - Gallery</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Cardo:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/main.css" rel="stylesheet">
  <link href="../assets/css/admin.css" rel="stylesheet">
  


  <!-- =======================================================
  * Template Name: PhotoFolio
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/photofolio-bootstrap-photography-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center  me-auto me-lg-0">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <i class="bi bi-camera"></i>
        <h1>PhotoFolio</h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php" class="active">Home</a></li>
          <li class="dropdown"><a href="#"><span>Galeria</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
              <li><a href="natureza.php">Natureza</a></li>
              <li><a href="pessoas.php">Pessoas</a></li>
              <li><a href="arquitetura.php">Arquitetura</a></li>
              <li><a href="animais.php">Animais</a></li>
              <li><a href="viagem.php">Viagens</a></li>
            </ul>
          </li>
          <li class = "useraname dropdown">
            <a href="#">
            <?php
            if (isset($_SESSION["nomeusuario"])){
              echo "<li><a href='index.html' class='active'>".$_SESSION['nomeusuario']."</a></li>";
            }else{
              echo "<li><a href='login.php' class='active'>Entrar</a></li>";
            }
            ?>
            </a>
            
          </li>
        </ul>
      </nav><!-- .navbar -->

      <div class="header-social-links">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

    </div>
  </header><!-- End Header -->
  <main>
    <section class="container-admin-banner">
      <!--<img src="../img/logo-ifsp-removebg.png" class="logo-admin" alt="logo-serenatto"> -->

      <!--<img class= "ornaments" src="../img/ornaments-coffee.png" alt="ornaments">-->
    </section>
    <h2>Catálogo de Imagens</h2>
    <?php if (isset($_POST['codcad'])) { ?>
      <label for="codigo">Imagem cadastrada com sucesso!</label>
    <?php } ?>
    <section class="container-table">
      <table>
        <thead>
          <tr>
            <th>Nome</th>
            <th>Descricão</th>
            <th>Categoria</th>
            <th colspan="2">Ação</th>

          </tr>
        </thead>
        <tbody>
          <?php foreach ($imagens as $imagem) : ?>
            <tr>
              <td><?= $imagem->getNome();  ?></td>
              <td><?= $imagem->getDescricao();  ?></td>
              <td><?= $imagem->getCategoria();  ?></td>
              <td>
                <form action="editar-foto.php" method="POST">
                  <input type="hidden" name="id" value="<?= $imagem->getId(); ?>">
                  <input type="hidden" name="nomeusuario" value="<?= $_SESSION['nomeusuario']; ?>">
                  <input type="hidden" name="usuario" value="<?= $_SESSION['usuario']; ?>">
                  <input type="submit" class="botao-editar" value="Editar">
                </form>

              </td>
              <td>
                <form action="excluir-foto.php" method="POST">
                  <input type="hidden" name="id" value="<?= $imagem->getId(); ?>">
                  <input type="hidden" name="nomeusuario" value="<?= $_SESSION['nomeusuario']; ?>">
                  <input type="hidden" name="usuario" value="<?= $_SESSION['usuario']; ?>">
                  <input type="submit" class="botao-excluir" value="Excluir">
                </form>
              </td>
            </tr>
          <?php endforeach; ?>

        </tbody>
      </table>
      <form action="cadastrar-foto.php" method="POST">
        <input type="hidden" name="nomeusuario" value="<?= $_SESSION['nomeusuario']; ?>">
        <input type="hidden" name="usuario" value="<?= $_SESSION['usuario']; ?>">
        <input type="submit" class="botao-cadastrar" name="cadastrar" value="Cadastrar Foto">
      </form>
      <form action="#" method="post">
        <input type="submit" class="botao-cadastrar" value="Baixar Relatório" />
      </form>
    </section>
  </main>
</body>

</html>