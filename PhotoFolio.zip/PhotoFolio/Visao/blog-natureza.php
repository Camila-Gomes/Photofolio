<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>DevFolio Bootstrap Portfolio Template - Blog Single</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: DevFolio
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/devfolio-bootstrap-portfolio-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<style>
  .botao-coment a:link, a:visited{
    margin: 10px;
    padding: 10px;
    background-color: #D4C1EC;
    border-radius: 5px;

  }
  .botao-coment{
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .title-left{
    color: #54426B;
  }
  .row{
    display: flex;
    justify-content: center;
    align-items: center;
  }
</style>
<body>

  <?php
    $imagemSelecionada = $_GET["imagem"];
    $origem = "../assets/img/natureza/*"; 
    $imagens = glob($origem);
    $substituir = Array("/", ".");
    
    for ($i=0; $i < count($imagens) ; $i++) { 
      if(str_replace($substituir, "", $imagens[$i]) === $imagemSelecionada) {
        $imagemSelecionada = $imagens[$i];
      };
    };
  ?>
  

  <main id="main">

    <!-- ======= Blog Single Section ======= -->
    <section class="blog-wrapper sect-pt4" id="blog">
      <div class="container">
        <div class="row">
          <div class="col-md-8">
            <div class="post-box">
              <div class="post-thumb">
                <img src=<?=$imagemSelecionada?> class="img-fluid" alt="">
              </div>
              <div class="post-meta">
                <h1 class="article-title">Lorem Impsun</h1>
                <ul>
                  <li>
                    <span class="bi bi-person"></span>
                    <a href="#">Jason London</a>
                  </li>
                  <li>
                    <span class="bi bi-tag"></span>
                    <a href="#">Web Design</a>
                  </li>
                  <li>
                    <span class="bi bi-chat-left-text"></span>
                    <a href="#">14</a>
                  </li>
                </ul>
              </div>
              <div class="article-content">
                <p>
                  Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Lorem ipsum dolor sit amet, consectetur
                  adipiscing elit. Praesent
                  sapien massa, convallis a pellentesque nec, egestas non nisi. Lorem ipsum dolor sit amet,
                  consectetur adipiscing elit. Curabitur arcu erat, accumsan id imperdiet et, porttitor at
                  sem. Donec rutrum congue leo eget malesuada.
                </p>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla quis lorem ut libero malesuada feugiat.
                  Curabitur arcu erat,
                  accumsan id imperdiet et, porttitor at sem. Vivamus suscipit tortor eget felis porttitor
                  volutpat. Vivamus suscipit tortor eget felis porttitor volutpat. Quisque velit nisi, pretium
                  ut lacinia in, elementum id enim.
                </p>
                <blockquote class="blockquote">
                  <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
                </blockquote>
                <p>
                  Nulla porttitor accumsan tincidunt. Cras ultricies ligula sed magna dictum porta. Mauris blandit
                  aliquet elit, eget tincidunt
                  nibh pulvinar a. Cras ultricies ligula sed magna dictum porta. Lorem ipsum dolor sit amet,
                  consectetur adipiscing elit. Donec sollicitudin molestie malesuada.
                </p>
              </div>
            </div>
            <div class="box-comments">
              <div class="title-box-2">
                <h4 class="title-comments title-left">Comments (34)</h4>
              </div>
              <ul class="list-comments">
                <li>
                  <div class="comment-avatar">
                    <img src="assets/img/comentario.png" alt="">
                  </div>
                  <div class="comment-details">
                    <h4 class="comment-author">Oliver Colmenares</h4>
                    <span>18 Sep 2017</span>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores reprehenderit, provident cumque
                      ipsam temporibus maiores
                      quae natus libero optio, at qui beatae ducimus placeat debitis voluptates amet corporis.
                    </p>
                  </div>
                </li>
      
                <li class="comment-children">
                  <div class="comment-avatar">
                    <img src="assets/img/comentario.png" alt="">
                  </div>
                  <div class="comment-details">
                    <h4 class="comment-author">Oliver Colmenares</h4>
                    <span>18 Sep 2017</span>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores reprehenderit, provident cumque
                      ipsam temporibus maiores
                      quae.
                    </p>
                  </div>
                </li>
              </ul>
            </div>
            <div class="form-comments">
              <div class="title-box-2">
                <h3 class="title-left">
                  Deseja fazer um comentário?
                </h3>
                <br><br>
                <div class="botao-coment">
                  <a href="login.php">Login</a>
                  <a href="cadastrar-usuario.php">Cadastro</a>
                </div>
              </div>
            </div>
          </div>
         
            
          </div>
        </div>
      </div>
    </section><!-- End Blog Single Section -->

  </main><!-- End #main -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/typed.js/typed.umd.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>

</body>

</html>