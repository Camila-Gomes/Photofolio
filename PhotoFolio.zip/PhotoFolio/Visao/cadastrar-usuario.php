<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>PhotoFolio Bootstrap Template - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Cardo:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/main.css" rel="stylesheet">
  <link href="../assets/css/login.css" rel="stylesheet">
  <link href="../assets/css/form.css" rel="stylesheet">
  <link href="../assets/css/menu.css" rel="stylesheet">
  <link href="../assets/css/reset.css" rel="stylesheet">




  <!-- =======================================================
  * Template Name: PhotoFolio
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/photofolio-bootstrap-photography-website-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<style>
  .container-form {
    font-family: "Inter", sans-serif;;
    display: flex;
    flex-direction: column;
    align-items: center;
    font-size: 15px;
  }
  .container-form h1{
    font-size: 35px;
    color: #54426B;
    font-family: var(--font-default);
    margin: 15px;
    padding: 15px;
  }
</style>
<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center  me-auto me-lg-0">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <i class="bi bi-camera"></i>
        <h1>PhotoFolio</h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php" class="active">Home</a></li>
          <li class="dropdown"><a href="#"><span>Gallery</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
              <li><a href="natureza.php">Natureza</a></li>
              <li><a href="pessoas.php">Pessoas</a></li>
              <li><a href="arquitetura.php">Arquitetura</a></li>
              <li><a href="animais.php">Animals</a></li>
              <li><a href="viagens.php">Viagens</a></li>
            </ul>
          </li>
        </ul>
      </nav><!-- .navbar -->

      <div class="header-social-links">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

    </div>
    </header><!-- End Header -->

<!-- ======= Hero Section ======= -->
<section id="hero" class="hero d-flex flex-column justify-content-center align-items-center" data-aos="fade" data-aos-delay="1500"></section><!-- End Hero Section -->
<body>
<main>
    <section class="container-form">
      <h1>Cadastro de Usuários</h1>
        <form method="post" action="../Controladora/processar-cadastro.php">
          <label for="nome">Nome</label>
          <input type="text" id="nome" name="nome" 
          placeholder="Digite um nome" required>
            
          <label for="email">E-mail</label>
          <input type="email" id="email" name="email" 
          placeholder="Digite seu email" required>

          <label for="senha">Senha</label>
          <input type="password" id="senha" name="senha" 
          placeholder="Digite uma senha" required>
           
          <label for="confirmarsenha">Confirmar Senha</label>
          <input type="password" id="confirmarsenha" name="confirmarsenha" 
          placeholder="Digite uma senha" required>
          <?php 
            if(isset($_GET["erro"])){
                //echo "erro! senha e confirmar senha não são iguais";
          ?>
          <label for="erro">Senha e confirmar senha não são iguais</label>
          <?php } ?>

            <input type="submit" name="cadastro" class="botao-cadastrar" 
            value="Cadastrar usuario"/>
        </form>
        

    </section>
</main>
</body>
</html>