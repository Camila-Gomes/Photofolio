<?php
session_start();
require "conexao.php";
//require "..\Modelo\Foto.php";
require "..\Repositorio\ImagemRepositorio.php";

//if (isset($_POST['cadastro'])){ ou
if ($_SERVER["REQUEST_METHOD"]=="POST"){
    $id = rand(1, 999);
    $nome = $_POST["nomeP"];
    $descricao = $_POST["descricao"];
    $newPath = "../assets/img/". uniqid(). $_FILES['imagem']['name'];
    $imagem = $newPath;
    $categoria = $_POST["categoria"];

    $_SESSION['usuario'] = $_POST['usuario'];
    $_SESSION['nomeusuario'] = $_POST['nomeusuario'];
    
    $imagens = new Foto( 
        $id,
        $nome,
        $descricao,
        $imagem,
        $categoria
    );

    $imagensRepositorio = new ImagemRepositorio($conn);
    if (isset($_FILES['imagem']) && ($_FILES['imagem']['error'] == 0)){
        $imagens->setImagem($newPath);
        move_uploaded_file($_FILES['imagem']['tmp_name'], $imagens->getImagem());
    }
    $sucess = $imagensRepositorio->cadastrar($imagens);
    if ($sucess){
        $codcad = rand(0, 1000000);
        echo "<form id='redirectForm' action='../Visao/admin.php' method='POST'>";
        echo "<input type='hidden' name='codigo' value={'$codcad'}>";

        echo "<input type='hidden' name='nomeusuario' value=".$_SESSION['nomeusuario'].">";
        echo "<input type='hidden' name='usuario' value=".$_SESSION['usuario'].">";
       
        echo "</form>";
        echo "<script>document.getElementById('redirectForm').submit();</script>";


       // header("Location: ../visao/admin.php?codcad=$codigo");
      //  exit();
    }else{
        echo "erro ao cadastrar produto";
    }
    
}









?>