<?php
include '../Modelo/Foto.php';
class ImagemRepositorio
{
    private $conn; // Sua conexão com o banco de dados
    public function __construct($conn)
    {
        $this->conn = $conn;
    }
    public function cadastrar(Foto $foto)
    {
        $sql = "INSERT INTO fotos (id, nome, descricao, 
        imagem, categoria) VALUES (?,?,?,?,?)";
        $stmt = $this->conn->prepare($sql);
            // Extrai os atributos do objeto Produto
        $id = $foto->getId();
        $nome = $foto->getNome();
        $descricao = $foto->getDescricao();
        $imagem = $foto->getImagem();
        $categoria = $foto->getCategoria();
        // Vincula os parâmetros
        $stmt->bind_param(
            'issss',
            $id,
            $nome,
            $descricao,
            $imagem,
            $categoria
        );

        // Executa a consulta preparada e verifica o sucesso
        $success = $stmt->execute();

        // Fecha a declaração
        $stmt->close();

        // Retorna um indicador de sucesso
        return $success;
    }


    public function listarFotos()
    {
        $sql = "SELECT * FROM fotos"; 
        $result = $this->conn->query($sql);

        $fotos = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $foto = new Foto(
                    $row['id'],
                    $row['nome'],
                    $row['descricao'],
                    $row['imagem'],
                    $row['categoria']

                    
                );
                $fotos[] = $foto;
            }
        }

        return $fotos;
    }
    public function atualizarFoto(Foto $foto)
    {
        $imagem = $foto->getImagem();
        if (empty($imagem)) {
            // Prepara a declaração SQL
            $sql = "UPDATE fotos SET WHERE id = ?, nome = ?,
            descricao = ?, imagem = ?, categoria = ?";
            $stmt = $this->conn->prepare($sql);

            // Extrai os atributos do objeto Produto
            $id = $foto->getId();
            $nome = $foto->getNome();
            $descricao = $foto->getDescricao();
            $imagem = $foto->getImagem();
            $categoria = $foto->getCategoria();


            // Vincula os parâmetros
            $stmt->bind_param(
                'issss',
                $id,
                $nome,
                $descricao,
                $imagem,
                $categoria
                
            );
            // Executa a declaração preparada
            $resultado = $stmt->execute();

            // Fecha a declaração
            $stmt->close();

            return $resultado;
        } else {
            // Prepara a declaração SQL
            $sql = "UPDATE fotos SET id = ?, nome = ?,
            descricao = ?, imagem = ?, categoria = ? WHERE id = ?";

            $stmt = $this->conn->prepare($sql);
            // Extrai os atributos do objeto Produto
            $id = $foto->getId();
            $nome = $foto->getNome();
            $descricao = $foto->getDescricao();
            $imagem = $foto->getImagem();
            $categoria = $foto->getCategoria();

            // Vincula os parâmetros
            $stmt->bind_param(
                'issssi',
                $id,
                $nome,
                $descricao,
                $imagem,
                $categoria,
                $id
            );
            // Executa a declaração preparada
            $resultado = $stmt->execute();

            // Fecha a declaração
            $stmt->close();

            return $resultado;
        }
    }

    public function listarFotoPorId($id)
    {
        $sql = "SELECT * FROM fotos WHERE id = ?";

        // Prepara a declaração SQL
        $stmt = $this->conn->prepare($sql);

        // Vincula o parâmetro
        $stmt->bind_param('i', $id);

        // Executa a consulta preparada
        $stmt->execute();

        // Obtém os resultados
        $result = $stmt->get_result();

        $foto = null;

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            $foto = new Foto(
                $row['id'],
                $row['nome'],
                $row['descricao'],
                $row['imagem'],
                $row['categoria']
               
                
            );
        }

        // Fecha a declaração
        $stmt->close();

        return $foto;
    }

    public function excluirFotoPorId($id)
    {
        $sql = "DELETE FROM fotos WHERE  
             id = ?";

        // Prepara a declaração SQL
        $stmt = $this->conn->prepare($sql);

        // Vincula o parâmetro
        $stmt->bind_param('i', $id);

        // Executa a consulta preparada
        $success = $stmt->execute();

        // Fecha a declaração
        $stmt->close();

        return $success;
    }

}
