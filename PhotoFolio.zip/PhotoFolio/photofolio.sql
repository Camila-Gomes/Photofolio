create database photofolio;
use photofolio;
CREATE TABLE `usuario` (
  `nome` varchar(255),
  `email` varchar(255) primary key,
  `senha` varchar(255));
  select * from usuario;


create table categorias (
id int primary key,
nome varchar (100));

create table fotos (
id int primary key,
nome varchar (100),
descricao varchar (255),
imagem varchar (255),
categoria int);

insert into categorias (id, nome) values (1,"home"),(2,"natureza"),(3,"pessoas"),(4,"arquitetura"),(5,"animais"),(6,"viagens");
insert into fotos (id,nome,descricao,imagem,categoria) values (1,"Torre Eiffel","Torre Eiffel","../assets/img/home/1.png",1);
insert into fotos (id,nome,descricao,imagem,categoria) values (2,"Castelo","Lindo castelo na Inglaterra","../assets/img/home/2.png",2);
insert into fotos (id,nome,descricao,imagem,categoria) values (3,"3","Imagem panorâmica de Nova York","../assets/img/home/3.png",3);
insert into fotos (id,nome,descricao,imagem,categoria) values (4,"4","Ilha em Dubai","../assets/img/home/4.png",4);
insert into fotos (id,nome,descricao,imagem,categoria) values (5,"5","Itália","../assets/img/home/5.png",5);
insert into fotos (id,nome,descricao,imagem,categoria) values (6,"6","Suiça","../assets/img/home/6.png",6);
insert into fotos (id,nome,descricao,imagem,categoria) values (7,"7","Cidade","../assets/img/home/7.png",6);
insert into fotos (id,nome,descricao,imagem,categoria) values (8,"8","natureza muito bonita","../assets/img/home/8.png",6);


select * from fotos;

drop database photofolio;









